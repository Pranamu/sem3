# ludo
An android based ludo game which is played according to Nepali rule.
The game is developed entirely using java and xml in android studio.
