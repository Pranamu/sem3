# Title
  **Ludo**

## Description
  An android based Ludo game

## Type Of App
  Game
 
## Main Features
-  Play with a friend by sharing the phone.
-  Can Play four player as individual
-  Can play as a team, 2 v 2
-  Can save game and resume it
-  Player can choose side
-  Can play with or without sound
-  Winning animation
-  Can see match log

## Operating system
 Android OS

## Written In
> Java, XML

## Tools/framework used
Android Studio

